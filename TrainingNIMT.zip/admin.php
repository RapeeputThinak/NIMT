﻿<?php
require_once __DIR__ . '/admin_auth.php';
require_once __DIR__ . '/db_connection.php';
require_admin();

function formatLocalDateTime($timestamp, $format = 'd/m/Y H:i', $targetZone = 'Asia/Bangkok') {
    if (empty($timestamp)) {
        return '';
    }

    try {
        $dt = new DateTime($timestamp);
        $dt->setTimezone(new DateTimeZone($targetZone));
        return $dt->format($format);
    } catch (Exception $e) {
        return '';
    }
}

// รับค่าตัวกรองปีงบประมาณ หมวดหมู่ และเดือน
$fiscalYear = $_GET['fiscal_year'] ?? '';
$category = $_GET['category'] ?? ''; // ใช้จาก Sidebar แทน Dropdown
$month = $_GET['month'] ?? ''; // เดือนที่เลือก
$paymentStatus = $_GET['payment_status'] ?? '';

$params = [];
$whereClauses = [];
if (!empty($fiscalYear)) {
    $whereClauses[] = "fiscal_year = :fiscal_year";
    $params[':fiscal_year'] = $fiscalYear;
}
if (!empty($category)) {
    $whereClauses[] = "category = :category";
    $params[':category'] = $category;
}
if (!empty($month)) {
    // กรองตามเดือนของ training_date - PostgreSQL ใช้ EXTRACT
    $whereClauses[] = "EXTRACT(MONTH FROM training_date) = :month";
    $params[':month'] = intval($month);
}
if ($paymentStatus !== '') {
    // ถ้าต้องการดูรายการยังไม่ชำระ ให้รวมค่า NULL ด้วย (เดิมอาจไม่มีคอลัมน์)
    if ($paymentStatus === 'pending') {
        $whereClauses[] = "(payment_status = :payment_status OR payment_status IS NULL)";
        $params[':payment_status'] = 'pending';
    } else {
        $whereClauses[] = "payment_status = :payment_status";
        $params[':payment_status'] = $paymentStatus;
    }
}

$whereSql = '';
if (!empty($whereClauses)) {
    $whereSql = 'WHERE ' . implode(' AND ', $whereClauses);
}

$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 12;
$offset = ($page - 1) * $perPage;

// Count total rows
$countSQL = "SELECT COUNT(*) AS total FROM bookings $whereSql";
$countStmt = $conn->prepare($countSQL);
$countStmt->execute($params);
$countData = $countStmt->fetch(PDO::FETCH_ASSOC);
$totalRows = intval($countData['total'] ?? 0);

$totalPages = max(1, ceil($totalRows / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $perPage;
}

// Fetch data
$sql = "SELECT * FROM bookings $whereSql ORDER BY id DESC LIMIT $perPage OFFSET $offset";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// จัดการชื่อหมวดหมู่ที่กำลังแสดงอยู่
$categories = [
    '' => 'รายการทั้งหมด',
    'Inhouse-TH' => 'Inhouse (ไทย)',
    'Inhouse-EN' => 'Inhouse (อังกฤษ)',
    'Academic-TH' => 'Academic (ไทย)',
    'Academic-EN' => 'Academic (อังกฤษ)',
    'Metrology-TH' => 'Metrology (ไทย)',
    'Metrology-EN' => 'Metrology (อังกฤษ)'
];
$currentCategoryName = $categories[$category] ?? 'รายการทั้งหมด';

// Load pricing config untuk dashboard
$configFile = __DIR__ . '/pricing_config.json';
$pricingConfig = [];
if (file_exists($configFile)) {
    $raw = file_get_contents($configFile);
    $pricingConfig = json_decode($raw, true) ?? [];
}

// Get dashboard statistics
$dashboardStats = [
    'total' => $totalRows,
    'pending' => 0,
    'paid' => 0
];

try {
    $pendingStmt = $conn->query("SELECT COUNT(*) AS count FROM bookings WHERE payment_status IS NULL OR payment_status = 'pending'");
    $dashboardStats['pending'] = intval($pendingStmt->fetchColumn() ?? 0);
    
    $paidStmt = $conn->query("SELECT COUNT(*) AS count FROM bookings WHERE payment_status = 'paid'");
    $dashboardStats['paid'] = intval($paidStmt->fetchColumn() ?? 0);
} catch (Exception $e) {
    // Silent fail
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- เพิ่ม Meta Tag สำหรับเก็บ CSRF Token ป้องกัน JS Syntax Error -->
    <meta name="csrf-token" content="<?= function_exists('get_csrf_token') ? htmlspecialchars(get_csrf_token(), ENT_QUOTES, 'UTF-8') : 'mock-token' ?>">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;600;700&display=swap" rel="stylesheet">
    <title>ระบบจัดการข้อมูลการอบรม - NIMT Admin</title>
    <style>
        body { font-family: 'Sarabun', sans-serif; }
        /* แต่ง Scrollbar เมนูด้านซ้าย */
        .sidebar-scroll::-webkit-scrollbar { width: 4px; }
        .sidebar-scroll::-webkit-scrollbar-track { background: transparent; }
        .sidebar-scroll::-webkit-scrollbar-thumb { background: #3b82f6; border-radius: 4px; }
    </style>
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden">

    <!-- Overlay สีดำโปร่งแสงสำหรับมือถือ -->
    <div id="sidebarOverlay" class="fixed inset-0 bg-slate-900/50 z-20 hidden md:hidden transition-opacity duration-300" onclick="toggleSidebar()"></div>

    <!-- Sidebar ด้านข้าง -->
    <!-- ปรับคลาสให้รองรับการสไลด์ (Transform & Margin) -->
    <aside id="sidebar" class="w-64 shrink-0 bg-blue-900 text-white flex-col shadow-xl z-30 absolute inset-y-0 left-0 transform -translate-x-full transition-all duration-300 ease-in-out md:relative md:translate-x-0 flex">
        <!-- จัดตำแหน่ง Header ของ Sidebar ใหม่ ให้สูง 76px เท่ากับ Navbar ด้านขวา และให้อยู่กึ่งกลาง -->
        <div class="h-[76px] px-5 border-b border-blue-800/80 flex items-center gap-3.5 shrink-0">
            <!-- ปุ่ม 3 ขีด (Hamburger Menu) -->
            <button onclick="toggleSidebar()" class="p-2 -ml-2 bg-blue-800/50 hover:bg-blue-700 text-blue-100 hover:text-white rounded-lg focus:outline-none transition-colors">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
            <div class="flex flex-col justify-center">
                <h2 class="text-[20px] font-bold leading-none tracking-wide text-white mb-1.5">NIMT Admin</h2>
                <p class="text-blue-300 text-[11px] font-medium leading-none">ระบบจัดการข้อมูลการอบรม</p>
            </div>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-3 overflow-y-auto sidebar-scroll">
            <p class="text-xs text-blue-400 font-semibold uppercase tracking-wider mb-3 mt-4 px-3">เมนูหลัก</p>
            <a href="?category=&fiscal_year=<?= $fiscalYear ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $category === '' ? 'bg-blue-700 text-white font-semibold' : 'text-blue-200 hover:bg-blue-800 hover:text-white' ?>">
                <div class="w-10 h-10 flex items-center justify-center rounded-lg <?= $category === '' ? 'bg-blue-600/40' : 'bg-blue-800/40' ?>">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z"></path></svg>
                </div>
                <span>รายการทั้งหมด</span>
            </a>

            <p class="text-xs text-blue-400 font-semibold uppercase tracking-wider mb-3 mt-6 px-3">Inhouse Training</p>
            <a href="?category=Inhouse-TH&fiscal_year=<?= $fiscalYear ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $category === 'Inhouse-TH' ? 'bg-blue-700 text-white font-semibold' : 'text-blue-200 hover:bg-blue-800 hover:text-white' ?>">
                <div class="w-10 h-10 flex items-center justify-center rounded-lg bg-blue-600/30">
                    <span class="text-xl">🇹🇭</span>
                </div>
                <span>Inhouse (ไทย)</span>
            </a>
            <a href="?category=Inhouse-EN&fiscal_year=<?= $fiscalYear ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $category === 'Inhouse-EN' ? 'bg-blue-700 text-white font-semibold' : 'text-blue-200 hover:bg-blue-800 hover:text-white' ?>">
                <div class="w-10 h-10 flex items-center justify-center rounded-lg bg-blue-600/30">
                    <span class="text-xl">🇬🇧</span>
                </div>
                <span>Inhouse (อังกฤษ)</span>
            </a>

            <p class="text-xs text-blue-400 font-semibold uppercase tracking-wider mb-3 mt-6 px-3">Academic</p>
            <a href="?category=Academic-TH&fiscal_year=<?= $fiscalYear ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $category === 'Academic-TH' ? 'bg-blue-700 text-white font-semibold' : 'text-blue-200 hover:bg-blue-800 hover:text-white' ?>">
                <div class="w-10 h-10 flex items-center justify-center rounded-lg bg-purple-600/30">
                    <span class="text-xl">🇹🇭</span>
                </div>
                <span>Academic (ไทย)</span>
            </a>
            <a href="?category=Academic-EN&fiscal_year=<?= $fiscalYear ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $category === 'Academic-EN' ? 'bg-blue-700 text-white font-semibold' : 'text-blue-200 hover:bg-blue-800 hover:text-white' ?>">
                <div class="w-10 h-10 flex items-center justify-center rounded-lg bg-purple-600/30">
                    <span class="text-xl">🇬🇧</span>
                </div>
                <span>Academic (อังกฤษ)</span>
            </a>

            <p class="text-xs text-blue-400 font-semibold uppercase tracking-wider mb-3 mt-6 px-3">Metrology</p>
            <a href="?category=Metrology-TH&fiscal_year=<?= $fiscalYear ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $category === 'Metrology-TH' ? 'bg-blue-700 text-white font-semibold' : 'text-blue-200 hover:bg-blue-800 hover:text-white' ?>">
                <div class="w-10 h-10 flex items-center justify-center rounded-lg bg-cyan-600/30">
                    <span class="text-xl">🇹🇭</span>
                </div>
                <span>Metrology (ไทย)</span>
            </a>
            <a href="?category=Metrology-EN&fiscal_year=<?= $fiscalYear ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $category === 'Metrology-EN' ? 'bg-blue-700 text-white font-semibold' : 'text-blue-200 hover:bg-blue-800 hover:text-white' ?>">
                <div class="w-10 h-10 flex items-center justify-center rounded-lg bg-cyan-600/30">
                    <span class="text-xl">🇬🇧</span>
                </div>
                <span>Metrology (อังกฤษ)</span>
            </a>
        </nav>
    </aside>

    <!-- พื้นที่เนื้อหาหลัก (Main Content) -->
    <main class="flex-1 flex flex-col h-screen overflow-hidden min-w-0">
        
        <!-- Top Navbar -->
        <header class="bg-white shadow-sm px-4 md:px-8 py-3 flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 z-10 relative min-h-[76px]">
            <div class="flex items-center gap-4 h-full">
                <!-- ปุ่ม 3 ขีด ด้านนอก (จะซ่อนไว้เมื่อ Sidebar เปิดอยู่ และโชว์เมื่อ Sidebar ถูกพับ) -->
                <button id="openSidebarBtn" onclick="toggleSidebar()" class="md:hidden w-10 h-10 flex items-center justify-center bg-slate-50 border border-slate-200/80 rounded-xl text-slate-700 hover:bg-slate-100 hover:text-blue-700 focus:outline-none focus:ring-2 focus:ring-slate-200 transition-all shadow-sm cursor-pointer active:scale-95 shrink-0">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>
                <div class="flex flex-col justify-center">
                    <h1 class="text-[20px] font-bold text-gray-800 leading-none mb-1.5"><?= $currentCategoryName ?></h1>
                    <span class="text-sm text-gray-500 leading-none">แสดง <?= count($rows) ?> จาก <?= $totalRows ?> รายการ (หน้า <?= $page ?> / <?= $totalPages ?>)</span>
                </div>
            </div>
            
            <div class="flex flex-wrap items-center gap-4">
                <!-- ตัวกรองปีงบประมาณ และเดือน -->
                <form method="get" class="flex items-center gap-3 flex-wrap">
                    <input type="hidden" name="category" value="<?= htmlspecialchars($category) ?>">
                    <div class="flex items-center gap-2">
                        <label class="text-sm text-gray-600 font-medium hidden sm:block">ปีงบฯ:</label>
                        <select name="fiscal_year" class="border border-gray-300 rounded-md px-3 py-1.5 text-sm focus:ring-blue-500 focus:border-blue-500 bg-white" onchange="this.form.submit()">
                            <option value="">ทุกปี</option>
                            <?php foreach (['2025-2026','2026-2027','2027-2028','2028-2029','2029-2030','2030-2031','2031-2032','2032-2033'] as $fy): ?>
                                <option value="<?= $fy ?>" <?= $fiscalYear === $fy ? 'selected' : '' ?>><?= $fy ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="flex items-center gap-2">
                        <label class="text-sm text-gray-600 font-medium hidden sm:block">เดือน:</label>
                        <select name="month" class="border border-gray-300 rounded-md px-3 py-1.5 text-sm focus:ring-blue-500 focus:border-blue-500 bg-white" onchange="this.form.submit()">
                            <option value="">ทุกเดือน</option>
                            <option value="1" <?= $month === '1' ? 'selected' : '' ?>>มกราคม</option>
                            <option value="2" <?= $month === '2' ? 'selected' : '' ?>>กุมภาพันธ์</option>
                            <option value="3" <?= $month === '3' ? 'selected' : '' ?>>มีนาคม</option>
                            <option value="4" <?= $month === '4' ? 'selected' : '' ?>>เมษายน</option>
                            <option value="5" <?= $month === '5' ? 'selected' : '' ?>>พฤษภาคม</option>
                            <option value="6" <?= $month === '6' ? 'selected' : '' ?>>มิถุนายน</option>
                            <option value="7" <?= $month === '7' ? 'selected' : '' ?>>กรกฎาคม</option>
                            <option value="8" <?= $month === '8' ? 'selected' : '' ?>>สิงหาคม</option>
                            <option value="9" <?= $month === '9' ? 'selected' : '' ?>>กันยายน</option>
                            <option value="10" <?= $month === '10' ? 'selected' : '' ?>>ตุลาคม</option>
                            <option value="11" <?= $month === '11' ? 'selected' : '' ?>>พฤศจิกายน</option>
                            <option value="12" <?= $month === '12' ? 'selected' : '' ?>>ธันวาคม</option>
                        </select>
                    </div>
                    <div class="flex items-center gap-2">
                        <label class="text-sm text-gray-600 font-medium hidden sm:block">สถานะชำระเงิน:</label>
                        <select name="payment_status" class="border border-gray-300 rounded-md px-3 py-1.5 text-sm focus:ring-blue-500 focus:border-blue-500 bg-white" onchange="this.form.submit()">
                            <option value="" <?= $paymentStatus === '' ? 'selected' : '' ?>>ทั้งหมด</option>
                            <option value="pending" <?= $paymentStatus === 'pending' ? 'selected' : '' ?>>ยังไม่ชำระ</option>
                            <option value="paid" <?= $paymentStatus === 'paid' ? 'selected' : '' ?>>ชำระแล้ว</option>
                        </select>
                    </div>
                    <a href="?category=<?= htmlspecialchars($category) ?>" class="text-sm text-gray-500 hover:text-blue-600 underline ml-1">ล้างค่า</a>
                </form>
  
                <?php if(!empty($_SESSION['is_admin'])): ?>
                    <div class="flex items-center gap-2 flex-wrap">
                        <a href="admin_select.php" class="text-sm bg-slate-50 text-slate-800 border border-slate-200 px-3 py-1.5 rounded hover:bg-slate-200 transition">เลือกประเภท</a>
                        <a href="admin_prices.php" class="text-sm bg-blue-50 text-blue-700 border border-blue-200 px-3 py-1.5 rounded hover:bg-blue-600 hover:text-white transition">แก้ไขราคา</a>
                        <button onclick="confirmBulkDelete()" class="text-sm bg-red-50 text-red-600 border border-red-200 px-3 py-1.5 rounded hover:bg-red-600 hover:text-white transition">ลบที่เลือก</button>
                        <a href="admin_logout.php" class="text-sm text-red-600 hover:underline ml-2">ออกจากระบบ</a>
                    </div>
                <?php else: ?>
                    <div>
                        <a href="admin_login.php" class="text-sm text-blue-600 hover:underline">เข้าสู่ระบบ</a>
                    </div>
                <?php endif; ?>
            </div>
        </header>

        <!-- ตารางแสดงผล -->
        <div class="flex-1 overflow-auto p-4 md:p-8 relative">
            <!-- Dashboard Statistics Cards -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <!-- Card 1: Total Requests -->
                <div class="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-lg p-5 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-blue-700 font-medium mb-1">คำขอใช้บริการทั้งหมด</p>
                            <p class="text-3xl font-bold text-blue-900"><?= number_format($dashboardStats['total']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-blue-200 rounded-lg flex items-center justify-center">
                            <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"></path>
                                <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 1 1 0 000 2H3a1 1 0 00-1 1v10a1 1 0 001 1h14a1 1 0 001-1V6a1 1 0 00-1-1h3a1 1 0 000-2 2 2 0 00-2-2H4zm3 4a1 1 0 100 2h8a1 1 0 100-2H7z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                    </div>
                </div>

                <!-- Card 2: Pending Payment -->
                <div class="bg-gradient-to-br from-amber-50 to-amber-100 border border-amber-200 rounded-lg p-5 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-amber-700 font-medium mb-1">รอดำเนินการ</p>
                            <p class="text-3xl font-bold text-amber-900"><?= number_format($dashboardStats['pending']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-amber-200 rounded-lg flex items-center justify-center">
                            <svg class="w-6 h-6 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v3.5H7a1 1 0 100 2h4a1 1 0 001-1V7z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                    </div>
                </div>

                <!-- Card 3: Paid/Approved -->
                <div class="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-5 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-green-700 font-medium mb-1">อนุมัติ/ดำเนินการแล้ว</p>
                            <p class="text-3xl font-bold text-green-900"><?= number_format($dashboardStats['paid']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-green-200 rounded-lg flex items-center justify-center">
                            <svg class="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md border border-gray-100 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse whitespace-nowrap">
                        <thead>
                            <tr class="bg-gray-50 text-gray-700 text-sm border-b">
                                <th class="p-4 font-semibold"><input id="selectAll" type="checkbox" class="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"></th>
                                <th class="p-4 font-semibold">วันที่สมัคร</th>
                                <th class="p-4 font-semibold">หน่วยงาน</th>
                                <th class="p-4 font-semibold">เบอร์โทร</th>
                                <th class="p-4 font-semibold">อีเมล</th>
                                <!-- เพิ่ม text-center ให้หัวคอลัมน์ส่งอีเมลตรงกับปุ่มในตาราง -->
                                <th class="p-4 font-semibold text-center">ส่งอีเมล</th>
                                <th class="p-4 font-semibold">หลักสูตร</th>
                                <th class="p-4 font-semibold">วันที่อบรม</th>
                                <th class="p-4 font-semibold text-center">ปีงบประมาณ</th>
                                <th class="p-4 font-semibold text-center">สถานะชำระเงิน</th>
                                <th class="p-4 font-semibold text-center">สถานะส่งอีเมล</th>
                                <th class="p-4 font-semibold text-center">จัดการ</th>
                            </tr>
                        </thead>
                        <tbody class="text-sm divide-y divide-gray-100">
                            <?php if(!empty($rows) && count($rows) > 0): ?>
                                <?php foreach($rows as $row): ?>
                                <tr class="hover:bg-blue-50/50 transition">
                                    <td class="p-4 text-gray-600">
                                        <input type="checkbox" class="rowCheckbox w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer" value="<?= $row['id'] ?>">
                                    </td>
                                    <td class="p-4 text-gray-600">
                                        <?php if (!empty($row['created_at'])): ?>
                                            <?= formatLocalDateTime($row['created_at'], 'd/m/Y') ?>
                                            <div class="text-xs text-gray-400 mt-0.5"><?= formatLocalDateTime($row['created_at'], 'H:i') ?> น.</div>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-4 font-medium text-gray-800"><?= htmlspecialchars($row['company_name'] ?? 'ไม่ระบุ') ?></td>
                                    <td class="p-4 text-blue-600 font-medium"><?= htmlspecialchars($row['contact_phone'] ?? 'ไม่ระบุ') ?></td>
                                    <td class="p-4 text-gray-600 font-medium recipient-email"><?= htmlspecialchars($row['contact_email'] ?? 'ไม่ระบุ') ?></td>
                                    <td class="p-4 text-center">
                                        <?php if (!empty($row['contact_email']) && filter_var($row['contact_email'], FILTER_VALIDATE_EMAIL)): ?>
                                            <?php
                                                $recipientNameParam = urlencode($row['company_name'] ?? '');
                                                $speakerNameParam = urlencode($row['instructor_name'] ?? '');
                                                $courseNameParam = urlencode($row['course_title'] ?? '');
                                                $trainingDateParam = '';
                                                if (!empty($row['training_date']) && $row['training_date'] != '0000-00-00') {
                                                    $trainingDateParam = urlencode(date('d/m/Y', strtotime($row['training_date'])));
                                                }
                                                $attendeeCountParam = urlencode($row['participant_count'] ?? '');
                                            ?>
                                            <a href="EmailConfirmationForm.html?recipient_emails=<?= urlencode($row['contact_email']) ?>&recipientName=<?= $recipientNameParam ?>&courseName=<?= $courseNameParam ?>&speakerName=<?= $speakerNameParam ?>&trainingDate=<?= $trainingDateParam ?>&attendeeCount=<?= $attendeeCountParam ?>&booking_id=<?= $row['id'] ?>" class="inline-flex items-center justify-center px-3 py-1.5 bg-blue-50 text-blue-600 border border-blue-200 rounded-lg text-xs font-semibold hover:bg-blue-600 hover:text-white transition shadow-sm">ส่งอีเมล</a>
                                        <?php else: ?>
                                            <span class="text-gray-400 text-xs bg-gray-50 px-2 py-1 rounded">ไม่มีอีเมล</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-4 text-gray-600">
                                        <div class="truncate max-w-[200px]" title="<?= htmlspecialchars($row['course_title'] ?? 'ไม่ระบุ') ?>">
                                            <?= htmlspecialchars($row['course_title'] ?? 'ไม่ระบุ') ?>
                                        </div>
                                        <?php if($category === ''): // แสดง tag หมวดหมู่เฉพาะตอนอยู่หน้า "ทั้งหมด" ?>
                                            <div class="text-[10px] bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full inline-block mt-1 font-medium border border-indigo-100"><?= htmlspecialchars($row['category'] ?? '-') ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-4 text-blue-600 font-medium">
                                        <?php 
                                            if (!empty($row['training_date']) && $row['training_date'] != '0000-00-00') {
                                                echo date('d/m/Y', strtotime($row['training_date']));
                                            } else {
                                                echo "<span class='text-gray-400 font-normal'>ไม่ได้ระบุ</span>";
                                            }
                                        ?>
                                    </td>
                                    <td class="p-4 text-center font-semibold text-gray-600"><?= htmlspecialchars($row['fiscal_year'] ?? '-') ?></td>
                                    <?php
                                        // กำหนดสถานะปัจจุบัน โดยถือค่าว่าง/NULL เป็น 'pending'
                                        $currentStatus = ($row['payment_status'] ?? 'pending');
                                        $isPaid = $currentStatus === 'paid';
                                        $isEmailSent = !empty($row['email_sent']);
                                    ?>
                                    <td class="p-4 text-center">
                                        <select class="payment-status-select px-3 py-1.5 rounded text-xs font-bold border-2 cursor-pointer outline-none transition" onchange="updatePaymentStatus(<?= $row['id'] ?>, this.value)" data-booking-id="<?= $row['id'] ?>" style="border-color: <?= $isPaid ? '#10b981' : '#ef4444' ?>; color: <?= $isPaid ? '#059669' : '#dc2626' ?>; background-color: <?= $isPaid ? '#ecfdf5' : '#fef2f2' ?>;">
                                            <option value="paid" <?= $currentStatus === 'paid' ? 'selected' : '' ?>>ชำระแล้ว</option>
                                            <option value="pending" <?= $currentStatus === 'pending' ? 'selected' : '' ?>>ยังไม่ชำระ</option>
                                        </select>
                                    </td>
                                    <td class="p-4 text-center">
                                        <?php if ($isEmailSent): ?>
                                            <span class="bg-blue-100 text-blue-700 px-3 py-1.5 rounded-full text-[11px] font-bold inline-flex items-center gap-1 border border-blue-200">
                                                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path></svg> ส่งเมลแล้ว
                                            </span>
                                        <?php else: ?>
                                            <span class="bg-gray-100 text-gray-500 px-3 py-1.5 rounded-full text-[11px] font-bold inline-block border border-gray-200">ยังไม่ส่ง</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-4 text-center space-x-1">
                                        <a href="detail.php?id=<?= $row['id'] ?>" class="bg-blue-50 text-blue-600 border border-blue-200 px-3 py-1.5 rounded text-xs hover:bg-blue-600 hover:text-white transition inline-block">รายละเอียด</a>
                                        <a href="edit_booking.php?id=<?= $row['id'] ?>" class="bg-yellow-50 text-yellow-700 border border-yellow-200 px-3 py-1.5 rounded text-xs hover:bg-yellow-500 hover:text-white transition inline-block">แก้ไข</a>
                                        <button onclick="confirmDelete(<?= $row['id'] ?>)" class="bg-red-50 text-red-600 border border-red-200 px-3 py-1.5 rounded text-xs hover:bg-red-600 hover:text-white transition inline-block">ลบ</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="12" class="p-12 text-center text-gray-500 bg-gray-50/50">
                                        <div class="flex flex-col items-center justify-center">
                                            <svg class="w-12 h-12 text-gray-300 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path></svg>
                                            <p class="text-base font-medium text-gray-600">ไม่พบข้อมูลผู้สมัคร</p>
                                            <p class="text-xs text-gray-400 mt-1">ลองเปลี่ยนตัวกรองเดือนหรือปีงบประมาณด้านบนดูอีกครั้ง</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="mt-4 px-6 py-4 bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <p class="text-sm text-gray-600 font-medium">หน้า <?= $page ?> จาก <?= $totalPages ?> | จำนวนทั้งหมด <?= $totalRows ?> รายการ</p>
                <nav class="inline-flex rounded-lg shadow-sm overflow-hidden" aria-label="Pagination">
                    <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                        <a href="?<?= htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $p]))) ?>" class="px-4 py-2 border border-gray-200 text-sm font-medium transition-colors <?= $p === $page ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-700 hover:bg-gray-50' ?>">
                            <?= $p ?>
                        </a>
                    <?php endfor; ?>
                </nav>
            </div>
        </div>
        
        <!-- Delete confirmation modal (อยู่นอกเนื้อหาเพื่อไม่ให้ดันโครงสร้าง) -->
        <div id="deleteModal" class="fixed inset-0 bg-slate-900/60 hidden items-center justify-center z-[100] backdrop-blur-sm transition-opacity">
            <div class="bg-white rounded-2xl shadow-2xl w-11/12 max-w-md p-6 transform scale-100 transition-transform">
                <div class="flex items-center gap-3 mb-4 text-red-600">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                    <h3 class="text-xl font-bold text-gray-900">ยืนยันการลบข้อมูล</h3>
                </div>
                <p id="deleteModalText" class="text-sm text-gray-600 mb-5 leading-relaxed">คุณแน่ใจหรือไม่ว่าจะลบรายการนี้? การกระทำนี้ไม่สามารถย้อนกลับได้</p>
                
                <label class="block text-sm font-semibold text-gray-700 mb-2">เหตุผลการลบ (ไม่บังคับ)</label>
                <textarea id="deleteReason" class="w-full border border-gray-300 rounded-xl p-3 mb-6 text-sm outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 resize-none transition-shadow" rows="3" placeholder="ระบุเหตุผลหรือบันทึกข้อมูลประกอบการลบ"></textarea>
                
                <div class="flex justify-end gap-3">
                    <button onclick="closeDeleteModal()" class="px-5 py-2.5 rounded-xl font-semibold bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors">ยกเลิก</button>
                    <button id="confirmDeleteBtn" onclick="performDelete()" class="px-5 py-2.5 rounded-xl font-semibold bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-600/30 transition-all transform hover:-translate-y-0.5">ลบข้อมูล</button>
                </div>
            </div>
        </div>

    </main>

<script>
// Initialize CSRF token from meta tag
window.csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

// ฟังก์ชันเปิด-ปิดแถบเมนูด้านซ้าย (Hamburger Menu)
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const openBtn = document.getElementById('openSidebarBtn');
    
    // สำหรับหน้าจอมือถือ (สไลด์เข้า/ออก)
    sidebar.classList.toggle('-translate-x-full');
    overlay.classList.toggle('hidden');
    
    // สำหรับหน้าจอคอมพิวเตอร์ (หดพื้นที่โดยใช้ Margin ลบ)
    sidebar.classList.toggle('md:-ml-64');

    // สลับการแสดงผลปุ่ม 3 ขีด ด้านนอก (พับเมนู = โชว์ปุ่ม, เปิดเมนู = ซ่อนปุ่ม)
    if (openBtn) {
        if (sidebar.classList.contains('md:-ml-64')) {
            openBtn.classList.remove('md:hidden');
        } else {
            openBtn.classList.add('md:hidden');
        }
    }
}

// Checkbox เลือกทั้งหมด
document.addEventListener('DOMContentLoaded', function(){
    const selectAll = document.getElementById('selectAll');
    if (!selectAll) return;
    selectAll.addEventListener('change', function(){
        document.querySelectorAll('.rowCheckbox').forEach(cb => {
            cb.checked = selectAll.checked;
            // เน้นสีแถวที่ถูกเลือก
            const tr = cb.closest('tr');
            if(cb.checked) tr.classList.add('bg-blue-50/80');
            else tr.classList.remove('bg-blue-50/80');
        });
    });

    // เพิ่ม Event ให้ checkbox แต่ละแถวเพื่อเปลี่ยนสีพื้นหลัง
    document.querySelectorAll('.rowCheckbox').forEach(cb => {
        cb.addEventListener('change', function() {
            const tr = this.closest('tr');
            if(this.checked) tr.classList.add('bg-blue-50/80');
            else tr.classList.remove('bg-blue-50/80');
        });
    });
});

function collectEmails(useSelected = false) {
    const rows = document.querySelectorAll('tbody tr');
    const emails = [];
    rows.forEach(row => {
        const emailTd = row.querySelector('.recipient-email');
        const checkbox = row.querySelector('.rowCheckbox');
        if (!emailTd || !checkbox) return;
        const email = emailTd.textContent.trim();
        if (!email || email === 'ไม่ระบุ') return;
        if (useSelected) {
            if (!checkbox.checked) return;
        }
        emails.push(email);
    });
    return [...new Set(emails)].join(', ');
}

async function updatePaymentStatus(id, status) {
    try {
        const response = await fetch('update_payment_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': window.csrfToken
            },
            body: JSON.stringify({ id, status, send_email: false })
        });

        const data = await response.json();
        if (!response.ok || !data.success) {
            throw new Error(data.error || 'ไม่สามารถอัปเดตสถานะชำระเงินได้');
        }

        const select = document.querySelector(`select[data-booking-id="${id}"]`);
        if (!select) return;

        if (status === 'paid') {
            select.style.borderColor = '#10b981';
            select.style.color = '#059669';
            select.style.backgroundColor = '#ecfdf5';
        } else {
            select.style.borderColor = '#ef4444';
            select.style.color = '#dc2626';
            select.style.backgroundColor = '#fef2f2';
        }
        
        // Show lightweight floating toast instead of alert for better UX
        showToast('อัปเดตสถานะการชำระเงินเรียบร้อย', 'success');
        // ถ้ามีข้อมูลการส่งอีเมลจากเซิร์ฟเวอร์ ให้แสดงผลเพิ่มเติม
        if (data.mail) {
            if (data.mail === 'sent') {
                showToast('ส่งอีเมลยืนยันการชำระเงินเรียบร้อย', 'success');
            } else if (data.mail === 'no_recipient') {
                showToast('ไม่มีอีเมลผู้ติดต่อสำหรับส่งการยืนยัน', 'error');
            } else {
                showToast('การส่งอีเมลล้มเหลว: ' + data.mail, 'error');
            }
        }
    } catch (error) {
        console.error(error);
        const select = document.querySelector(`select[data-booking-id="${id}"]`);
        if (select) {
            const currentStatus = select.value;
            select.value = currentStatus === 'paid' ? 'pending' : 'paid';
        }
        showToast(error.message || 'เกิดข้อผิดพลาดขณะอัปเดตสถานะ', 'error');
    }
}

// ฟังก์ชันสร้าง Toast Notification เล็กๆ
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `fixed bottom-6 right-6 px-6 py-3 rounded-xl shadow-lg text-white font-semibold text-sm transform transition-all duration-300 translate-y-10 opacity-0 z-50 flex items-center gap-2 ${type === 'success' ? 'bg-emerald-600' : 'bg-red-600'}`;
    toast.innerHTML = type === 'success' ? `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg> ${message}` : `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg> ${message}`;
    
    document.body.appendChild(toast);
    
    // Animate In
    setTimeout(() => {
        toast.classList.remove('translate-y-10', 'opacity-0');
    }, 10);
    
    // Animate Out
    setTimeout(() => {
        toast.classList.add('translate-y-10', 'opacity-0');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Delete Logic
let bookingToDelete = null;

function collectSelectedIds() {
    const ids = [];
    document.querySelectorAll('.rowCheckbox:checked').forEach(cb => {
        const v = parseInt(cb.value);
        if (!isNaN(v)) ids.push(v);
    });
    return ids;
}

function confirmBulkDelete() {
    const ids = collectSelectedIds();
    if (!ids.length) {
        showToast('กรุณาเลือกอย่างน้อย 1 แถวเพื่อทำการลบ', 'error');
        return;
    }
    bookingToDelete = ids;
    const modal = document.getElementById('deleteModal');
    const txt = document.getElementById('deleteModalText');
    txt.innerHTML = `คุณกำลังจะลบข้อมูล <strong>${ids.length} รายการ</strong><br>การกระทำนี้จะลบข้อมูลออกจากฐานข้อมูลอย่างถาวร`;
    document.getElementById('deleteReason').value = '';
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function confirmDelete(id) {
    bookingToDelete = id;
    const modal = document.getElementById('deleteModal');
    const txt = document.getElementById('deleteModalText');
    txt.innerHTML = `คุณกำลังจะลบรายการรหัส <strong>#${id}</strong><br>การกระทำนี้จะลบข้อมูลออกจากฐานข้อมูลอย่างถาวร`;
    document.getElementById('deleteReason').value = '';
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeDeleteModal() {
    bookingToDelete = null;
    const modal = document.getElementById('deleteModal');
    modal.classList.remove('flex');
    modal.classList.add('hidden');
}

async function performDelete() {
    if (!bookingToDelete) return;
    const reason = document.getElementById('deleteReason').value || '';
    const ids = Array.isArray(bookingToDelete) ? bookingToDelete : [bookingToDelete];
    const btn = document.getElementById('confirmDeleteBtn');
    
    try {
        btn.innerHTML = `<svg class="animate-spin h-5 w-5 mr-2 inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> กำลังลบ...`;
        btn.disabled = true;

        const res = await fetch('delete_booking.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': window.csrfToken
            },
            body: JSON.stringify({ ids: ids, reason: reason })
        });
        const data = await res.json();
        if (!res.ok || !data.success) throw new Error(data.error || 'ลบไม่สำเร็จ');

        // ลบแถวออกจากตาราง
        ids.forEach(id => {
            const checkbox = document.querySelector('.rowCheckbox[value="' + id + '"]');
            if (checkbox) {
                const tr = checkbox.closest('tr');
                if (tr) {
                    tr.style.opacity = '0';
                    tr.style.transform = 'translateX(-20px)';
                    tr.style.transition = 'all 0.3s ease';
                    setTimeout(() => tr.remove(), 300);
                }
            }
        });

        showToast('ลบรายการเรียบร้อยแล้ว', 'success');
    } catch (err) {
        console.error(err);
        showToast(err.message || 'เกิดข้อผิดพลาดขณะลบ', 'error');
    } finally {
        closeDeleteModal();
        btn.innerHTML = 'ลบข้อมูล';
        btn.disabled = false;
    }
}
</script>

<!-- Script ป้องกันการกดย้อนกลับ (Back Button) -->
<script>
(function(){
    try {
        history.pushState({noBackExitsApp: true}, document.title, location.href);
        window.addEventListener('popstate', function (e) {
            window.location.href = 'admin_select.php';
        });
    } catch (err) {}
})();
</script>
</body>
</html>