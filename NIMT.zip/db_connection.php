<?php
/**
 * PostgreSQL Database Connection Configuration
 * Replaces mysqli connection with PDO PostgreSQL
 */

// Load environment variables if .env exists
if (file_exists(__DIR__ . '/.env')) {
    $env = parse_ini_file(__DIR__ . '/.env');
    foreach ($env as $key => $value) {
        putenv("$key=$value");
    }
}

// PostgreSQL connection configuration
$db_host = getenv('DB_HOST') ?: 'localhost';
$db_port = getenv('DB_PORT') ?: '5432';
$db_name = getenv('DB_NAME') ?: 'nimt_training';
$db_user = getenv('DB_USER') ?: 'postgres';
$db_pass = getenv('DB_PASS') ?: '';

try {
    $dsn = "pgsql:host=$db_host;port=$db_port;dbname=$db_name";
    $conn = new PDO($dsn, $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    // Set encoding to UTF-8
    $conn->exec("SET NAMES 'UTF-8'");
    
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

/**
 * Helper function to safely escape/bind parameters (replaces mysqli real_escape_string)
 * Use prepare statements instead for security
 */
function safe_query($sql, $params = []) {
    global $conn;
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

/**
 * Helper to fetch all results as associative array
 */
function fetch_all($stmt) {
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Helper to fetch single row
 */
function fetch_one($stmt) {
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Helper to get last inserted ID
 */
function last_insert_id() {
    global $conn;
    return $conn->lastInsertId();
}

/**
 * Helper to count rows from a statement
 */
function row_count($stmt) {
    return $stmt->rowCount();
}
?>
