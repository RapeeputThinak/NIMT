<?php
// ตรวจสอบสิทธิ์ admin
require_once __DIR__ . '/admin_auth.php';
require_admin();

require_once __DIR__ . '/db_connection.php';

// รับข้อมูลจาก request (อ่านครั้งเดียวเพราะ php://input อ่านได้ครั้งเดียว)
$requestBody = file_get_contents('php://input');
$input = json_decode($requestBody, true) ?? [];

// ตรวจสอบ CSRF Token อย่างชาญฉลาด
// เนื่องจาก php://input ถูกอ่านแล้ว ให้ใช้ข้อมูลที่อ่านมา
$token = '';
if (!empty($_POST['csrf_token'])) {
    $token = $_POST['csrf_token'];
} elseif (!empty($_SERVER['HTTP_X_CSRF_TOKEN'])) {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'];
} elseif (!empty($input['csrf_token'])) {
    $token = $input['csrf_token'];
}

// Validate CSRF token
if (!validate_csrf_token($token)) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
    exit;
}

$bookingId = intval($input['id'] ?? 0);
$newStatus = $input['status'] ?? '';
$sendEmail = isset($input['send_email']) ? filter_var($input['send_email'], FILTER_VALIDATE_BOOLEAN) : true;

// ตรวจสอบค่า
if (!$bookingId || !in_array($newStatus, ['paid', 'pending'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid input']);
    exit;
}

try {
    // สร้างคอลัมน์ payment_status หากยังไม่มี (ป้องกัน DB schema ที่ไม่ครบ)
    $stmt = $conn->prepare("SELECT column_name FROM information_schema.columns WHERE table_name = 'bookings' AND column_name = 'payment_status'");
    $stmt->execute();
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        $conn->exec("ALTER TABLE bookings ADD COLUMN payment_status VARCHAR(20) DEFAULT 'pending'");
    }

    // อัปเดตสถานะ
    $stmt = $conn->prepare("UPDATE bookings SET payment_status = :status WHERE id = :id");
    $stmt->execute([':status' => $newStatus, ':id' => $bookingId]);
    // หากสถานะเปลี่ยนเป็น 'paid' ให้ส่งอีเมลยืนยันการได้รับชำระเงิน
    $mailResult = null;
    if ($newStatus === 'paid' && $sendEmail) {
        // ดึงข้อมูล booking
        $stmt2 = $conn->prepare("SELECT * FROM bookings WHERE id = :id LIMIT 1");
        $stmt2->execute([':id' => $bookingId]);
        $booking = $stmt2->fetch(PDO::FETCH_ASSOC);

        if ($booking && !empty($booking['contact_email']) && filter_var($booking['contact_email'], FILTER_VALIDATE_EMAIL)) {
            // โหลดการตั้งค่าอีเมล และ PHPMailer
            require_once __DIR__ . '/email_config.php';
            require_once __DIR__ . '/PHPMailer/Exception.php';
            require_once __DIR__ . '/PHPMailer/PHPMailer.php';
            require_once __DIR__ . '/PHPMailer/SMTP.php';

            try {
                $fromAddress = $email_config['from']['address'] ?? 'no-reply@nimt.local';
                $fromName = $email_config['from']['name'] ?? 'NIMT';

                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                if (!empty($email_config['smtp']['enabled'])) {
                    $mail->isSMTP();
                    $mail->Host = $email_config['smtp']['host'];
                    $mail->SMTPAuth = true;
                    $mail->Username = $email_config['smtp']['username'];
                    $mail->Password = $email_config['smtp']['password'];
                    $mail->SMTPSecure = $email_config['smtp']['encryption'] ?? 'tls';
                    $mail->Port = $email_config['smtp']['port'] ?? 587;
                    $mail->SMTPOptions = [
                        'ssl' => [
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'allow_self_signed' => true,
                        ],
                    ];
                }

                $mail->CharSet = 'UTF-8';
                $mail->setFrom($fromAddress, $fromName);
                $mail->addAddress($booking['contact_email'], $booking['contact_name'] ?? '');

                $subject = 'ข้อความอีเมล์ได้รับการชำระค่าอบรมแล้ว'; // subject is already matching requested text (kept for clarity)
                $company = htmlspecialchars($booking['company_name'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
                $contactName = htmlspecialchars($booking['contact_name'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

                $body = '<p><strong>เรื่อง :</strong> แจ้งยืนยันการได้รับชำระค่าธรรมเนียม จาก ' . $company . ' เรียบร้อยแล้ว</p>'
                    . '<br />'
                    . '<p><strong>เรียน :</strong> ' . $contactName . '</p>'
                    . '<br />'
                    . '<p>ทางกลุ่มงานพัฒนาธุรกิจ (อบรม) ได้รับเอกสารการชำระค่าธรรมเนียมเรียบร้อยแล้ว '
                    . 'และนำส่งให้ฝ่ายบัญชีดำเนินการตรวจสอบรายการเงินโอน เพื่อออกใบกำกับภาษีและใบเสร็จรับเงิน '
                    . 'รูปแบบอิเล็กทรอนิกส์ (E-Tax &amp; E-Receipt) โดยเอกสารดังกล่าวเป็น <strong>“เอกสารที่ได้มีการจัดทำและส่งข้อมูลให้แก่กรมสรรพากรด้วยวิธีทางอิเล็กทรอนิกส์”</strong> '
                    . 'ซึ่งจะทำการจัดส่งไปยัง e-mail ของผู้ติดต่อจากระบบขอใช้บริการ ภายใน 7 วันทำการ หากมีข้อสงสัยด้านใบเสร็จรับเงิน/ใบกำกับภาษี สามารถติดต่อ 02 026 5400 ต่อ 4122 (งานบัญชี)</p>'
                    . '<br />'
                    . '<p>ขอแสดงความนับถือ<br>กลุ่มงานพัฒนาธุรกิจ (อบรม) ฝ่ายนโยบายและยุทธศาสตร์ สถาบันมาตรวิทยาแห่งชาติ<br>โทรศัพท์ 02 026 5400 ต่อ 8301-3 หรือ 081 840 2902</p>';

                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $body;
                $mail->AltBody = strip_tags($body);

                $sent = $mail->send();
                $mailResult = $sent ? 'sent' : 'failed';
            } catch (Exception $e) {
                $mailResult = 'error: ' . $e->getMessage();
            }
        } else {
            $mailResult = 'no_recipient';
        }
    }

    $response = ['success' => true, 'message' => 'Payment status updated successfully'];
    if ($mailResult !== null) $response['mail'] = $mailResult;
    echo json_encode($response);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
