<?php
require_once __DIR__ . '/db_connection.php';

try {
    // Use transactional safety
    if ($conn->inTransaction() === false) {
        $conn->beginTransaction();
    }

    // Add column if not exists (PostgreSQL supports IF NOT EXISTS)
    $conn->exec("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW()");

    // Backfill existing rows
    $conn->exec("UPDATE bookings SET created_at = NOW() WHERE created_at IS NULL");

    $conn->commit();
    echo "OK: created_at column ensured and backfilled.\n";
} catch (PDOException $e) {
    if ($conn && $conn->inTransaction()) {
        $conn->rollBack();
    }
    echo "ERROR: " . $e->getMessage() . "\n";
    exit(1);
}

$conn = null;
