<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/admin_auth.php';
// Require admin session — page is admin-only
require_admin();

require_once __DIR__ . '/db_connection.php';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'missing_id']);
    exit;
}

try {
    $stmt = $conn->prepare('SELECT id, contact_name, company_name, contact_email, contact_phone, course_title, training_date, participant_count FROM bookings WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        // นำค่าที่เป็น null เปลี่ยนเป็น empty string เพื่อความเรียบร้อยของ JSON
        foreach ($row as $k => $v) if ($v === null) $row[$k] = '';
        echo json_encode(['success' => true, 'booking' => $row]);
        exit;
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'not_found']);
        exit;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'db_error', 'message' => $e->getMessage()]);
    exit;
}

?>
