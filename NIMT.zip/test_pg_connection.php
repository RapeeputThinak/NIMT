<?php
require_once __DIR__ . '/db_connection.php';

try {
    $version = $conn->query("SELECT version()")->fetchColumn();
    echo "Connected to PostgreSQL successfully.\n";
    echo "PostgreSQL version: " . $version . "\n";
} catch (Exception $e) {
    echo "Connection succeeded but query failed: " . $e->getMessage() . "\n";
}
?>