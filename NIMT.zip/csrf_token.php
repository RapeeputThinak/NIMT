<?php
require_once __DIR__ . '/admin_auth.php';
require_admin();

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['csrf_token' => get_csrf_token()]);
