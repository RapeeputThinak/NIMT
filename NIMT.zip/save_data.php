<?php
session_start();
require_once __DIR__ . '/db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // เก็บข้อมูล session สำหรับ step ถัดไป
    $_SESSION['data_page1'] = $_POST;

    // รับค่าจากฟอร์ม (ไม่ต้อง real_escape_string ใน PostgreSQL, ใช้ parameterized queries)
    $company_name      = $_POST['company_name'] ?? '';
    $billing_address   = $_POST['billing_address'] ?? '';
    $tax_id            = $_POST['tax_id'] ?? '';
    $branch_code       = $_POST['branch_code'] ?? '';
    $course_title      = $_POST['course_title'] ?? '';
    $instructor_name   = $_POST['instructor_name'] ?? '';
    $participant_count = intval($_POST['participant_count'] ?? 0);
    $location          = $_POST['location'] ?? '';
    $contact_name      = $_POST['contact_name'] ?? '';
    $contact_position  = $_POST['contact_position'] ?? '';
    $contact_phone     = $_POST['contact_phone'] ?? '';
    $contact_email     = $_POST['contact_email'] ?? '';
    $arrange_service   = $_POST['arrange_service'] ?? '';
    $site_vehicle      = isset($_POST['site_vehicle']) ? 'ใช่' : 'ไม่';
    $site_hotel        = isset($_POST['site_hotel']) ? 'ใช่' : 'ไม่';
    $nimt_room         = isset($_POST['nimt_room']) ? 'ใช่' : 'ไม่';
    $nimt_food         = isset($_POST['nimt_food']) ? 'ใช่' : 'ไม่';
    $consent           = isset($_POST['privacy_consent']) ? 'ยินยอม' : 'ไม่ยินยอม';
    $category          = $_POST['category'] ?? '';
    $shipping_address  = $_POST['shipping_address'] ?? '';

    // แปลงวันที่จาก d/m/Y เป็น Y-m-d
    $training_date = $_POST['training_date'] ?? '';
    if (strpos($training_date, '/') !== false) {
        $dateObj = DateTime::createFromFormat('d/m/Y', $training_date);
        if ($dateObj) {
            $training_date = $dateObj->format('Y-m-d');
        }
    }

    try {
        try {
            $check = $conn->prepare("SELECT column_name FROM information_schema.columns WHERE table_name = 'bookings' AND column_name = 'shipping_address'");
            $check->execute();
            if (!$check->fetch()) {
                $conn->exec("ALTER TABLE bookings ADD COLUMN shipping_address TEXT NULL");
            }
        } catch (PDOException $e) {
            // ignore schema creation failures
        }

        $sql = "INSERT INTO bookings (
                    company_name, billing_address, tax_id, branch_code,
                    course_title, instructor_name, participant_count, training_date,
                    location, contact_name, contact_position, contact_phone,
                    contact_email, arrange_service, site_vehicle, site_hotel,
                    nimt_room, nimt_food, consent, category, shipping_address
                ) VALUES (
                    :company_name, :billing_address, :tax_id, :branch_code,
                    :course_title, :instructor_name, :participant_count, :training_date,
                    :location, :contact_name, :contact_position, :contact_phone,
                    :contact_email, :arrange_service, :site_vehicle, :site_hotel,
                    :nimt_room, :nimt_food, :consent, :category, :shipping_address
                )";

        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':company_name' => $company_name,
            ':billing_address' => $billing_address,
            ':tax_id' => $tax_id,
            ':branch_code' => $branch_code,
            ':course_title' => $course_title,
            ':instructor_name' => $instructor_name,
            ':participant_count' => $participant_count,
            ':training_date' => $training_date,
            ':location' => $location,
            ':contact_name' => $contact_name,
            ':contact_position' => $contact_position,
            ':contact_phone' => $contact_phone,
            ':contact_email' => $contact_email,
            ':arrange_service' => $arrange_service,
            ':site_vehicle' => $site_vehicle,
            ':site_hotel' => $site_hotel,
            ':nimt_room' => $nimt_room,
            ':nimt_food' => $nimt_food,
            ':consent' => $consent,
            ':category' => $category,
            ':shipping_address' => $shipping_address,
        ]);

        header("Location: Inhouse_services.html");
        exit();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
