<?php
require_once __DIR__ . '/admin_auth.php';
require_admin();
require_once __DIR__ . '/db_connection.php';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Missing id']);
    exit;
}

try {
    $stmt = $conn->prepare('SELECT payment_status FROM bookings WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        echo json_encode(['success' => false, 'error' => 'Booking not found']);
        exit;
    }

    $status = $row['payment_status'] ?? 'pending';
    echo json_encode(['success' => true, 'status' => $status]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

?>
