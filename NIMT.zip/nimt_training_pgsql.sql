-- PostgreSQL schema for the bookings table
-- Use this file to create the table in pgAdmin or psql for PostgreSQL.

CREATE TABLE bookings (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255),
    billing_address TEXT,
    tax_id VARCHAR(20),
    branch_code VARCHAR(50),
    course_title VARCHAR(255),
    lab_tool VARCHAR(255),
    instructor_name VARCHAR(255),
    participant_count INT,
    training_date DATE,
    location VARCHAR(255),
    contact_name VARCHAR(255),
    contact_position VARCHAR(255),
    contact_phone VARCHAR(20),
    contact_email VARCHAR(100),
    request_date DATE,
    reference_no VARCHAR(100),
    arrange_service VARCHAR(50),
    site_vehicle VARCHAR(10),
    site_hotel VARCHAR(10),
    nimt_room VARCHAR(10),
    nimt_food VARCHAR(10),
    consent VARCHAR(10),
    category VARCHAR(50),
    fiscal_year VARCHAR(20),
    payment_status VARCHAR(20) DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid')),
    email_sent SMALLINT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
