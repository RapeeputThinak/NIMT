﻿<?php
session_start();
require_once __DIR__ . '/db_connection.php';
require_once __DIR__ . '/email_config.php';
require_once __DIR__ . '/PHPMailer/Exception.php';
require_once __DIR__ . '/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index2.html');
    exit();
}

$p1 = $_SESSION['data_page1'] ?? null;
if (empty($p1)) {
    echo "<script>alert('ไม่พบข้อมูลจากหน้าแรก กรุณาเริ่มกรอกข้อมูลใหม่'); window.location.href='metrology_form.html';</script>";
    exit();
}

$company_name      = trim($p1['company_name'] ?? '');
$billing_address   = trim($p1['billing_address'] ?? '');
$tax_id            = trim($p1['tax_id'] ?? '');
$branch_code       = trim($p1['branch_code'] ?? '');
$course_title      = trim($p1['course_title'] ?? '');
$instructor_name   = trim($p1['instructor_name'] ?? $p1['speaker_name'] ?? $p1['lecturer'] ?? '');
$participant_count = intval($p1['participant_count'] ?? 0);
$training_date     = trim($p1['training_date'] ?? '');
$location          = trim($p1['location'] ?? '');
$contact_name      = trim($p1['contact_name'] ?? '');
$contact_position  = trim($p1['contact_position'] ?? '');
$contact_phone     = trim($p1['contact_phone'] ?? '');
$contact_email     = trim($p1['contact_email'] ?? '');
$lab_tool          = trim($p1['lab_tool'] ?? '');
$request_date      = trim($p1['request_date'] ?? '');
$reference_no      = trim($p1['reference_no'] ?? $p1['ref_no'] ?? '');
$shipping_address  = trim($p1['shipping_address'] ?? '');

$arrange_service   = trim($_POST['arrange_service'] ?? '');
$site_vehicle      = isset($_POST['site_vehicle']) ? 'ใช่' : 'ไม่';
$site_hotel        = isset($_POST['site_hotel']) ? 'ใช่' : 'ไม่';
$nimt_room         = isset($_POST['nimt_room']) ? 'ใช่' : 'ไม่';
$nimt_food         = isset($_POST['nimt_food']) ? 'ใช่' : 'ไม่';
$consent           = (isset($_POST['privacy_consent']) || isset($p1['privacy_consent']) || isset($_POST['consent'])) ? 'ยินยอม' : 'ไม่ยินยอม';
$category          = trim($_POST['category'] ?? $p1['category'] ?? '');

if (strpos($training_date, '/') !== false) {
    $dateObj = DateTime::createFromFormat('d/m/Y', $training_date);
    if ($dateObj) {
        $training_date = $dateObj->format('Y-m-d');
    }
}

$fiscal_year = '';
if (!empty($training_date) && $training_date !== '0000-00-00') {
    $date_parts = explode('-', $training_date);
    if (count($date_parts) === 3) {
        $year = (int) $date_parts[0];
        $month = (int) $date_parts[1];
        $fiscal_year = ($month >= 10) ? $year . '-' . ($year + 1) : ($year - 1) . '-' . $year;
    }
}

// Ensure shipping_address column exists for persistent storage
try {
    $check = $conn->prepare("SELECT column_name FROM information_schema.columns WHERE table_name = 'bookings' AND column_name = 'shipping_address'");
    $check->execute();
    if (!$check->fetch()) {
        $conn->exec("ALTER TABLE bookings ADD COLUMN shipping_address TEXT NULL");
    }
} catch (PDOException $e) {
    // ignore if schema access is not supported
}

$sql = "INSERT INTO bookings (
            company_name, billing_address, tax_id, branch_code,
            course_title, instructor_name, lab_tool, participant_count, training_date,
            location, contact_name, contact_position, contact_phone,
            contact_email, request_date, reference_no,
            arrange_service, site_vehicle, site_hotel,
            nimt_room, nimt_food, consent, category, fiscal_year,
            shipping_address
        ) VALUES (
            :company_name, :billing_address, :tax_id, :branch_code,
            :course_title, :instructor_name, :lab_tool, :participant_count, :training_date,
            :location, :contact_name, :contact_position, :contact_phone,
            :contact_email, :request_date, :reference_no,
            :arrange_service, :site_vehicle, :site_hotel,
            :nimt_room, :nimt_food, :consent, :category, :fiscal_year,
            :shipping_address
        )";

try {
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':company_name' => $company_name,
        ':billing_address' => $billing_address,
        ':tax_id' => $tax_id,
        ':branch_code' => $branch_code,
        ':course_title' => $course_title,
        ':instructor_name' => $instructor_name,
        ':lab_tool' => $lab_tool,
        ':participant_count' => $participant_count,
        ':training_date' => $training_date,
        ':location' => $location,
        ':contact_name' => $contact_name,
        ':contact_position' => $contact_position,
        ':contact_phone' => $contact_phone,
        ':contact_email' => $contact_email,
        ':request_date' => $request_date,
        ':reference_no' => $reference_no,
        ':arrange_service' => $arrange_service,
        ':site_vehicle' => $site_vehicle,
        ':site_hotel' => $site_hotel,
        ':nimt_room' => $nimt_room,
        ':nimt_food' => $nimt_food,
        ':consent' => $consent,
        ':category' => $category,
        ':fiscal_year' => $fiscal_year,
        ':shipping_address' => $shipping_address,
    ]);

    if (!empty($contact_email)) {
        try {
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host       = $email_config['smtp']['host'] ?? 'localhost';
            $mail->SMTPAuth   = !empty($email_config['smtp']['username']);
            $mail->Username   = $email_config['smtp']['username'] ?? '';
            $mail->Password   = $email_config['smtp']['password'] ?? '';
            $mail->SMTPSecure = !empty($email_config['smtp']['encryption']) && strtolower($email_config['smtp']['encryption']) === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = intval($email_config['smtp']['port'] ?? 587);
            $mail->CharSet    = 'UTF-8';

            $mail->setFrom($email_config['from']['address'] ?? 'no-reply@nimt.local', $email_config['from']['name'] ?? 'NIMT');
            $mail->addAddress($contact_email, $contact_name ?: $company_name);
            $mail->isHTML(true);
            $mail->Subject = 'ข้อความอีเมล์ได้รับการแจ้งขอใช้บริการเรียบร้อยแล้ว';
            $mail->Body = "<div style='font-family: Arial, sans-serif; line-height: 1.6;'>" .
                "<p>เรื่อง : ท่านได้ส่งแจ้งแบบคำขอใช้บริการ <strong>" . htmlspecialchars($course_title) . "</strong> เรียบร้อยแล้ว</p>" .
                "<p>เรียน " . htmlspecialchars($contact_name) . "</p>" .
                "<p>ทางสถาบันมาตรวิทยาแห่งชาติ ได้รับแบบคำขอใช้บริการ <strong>" . htmlspecialchars($course_title) . "</strong> ของ คุณ" . htmlspecialchars($contact_name) . " เรียบร้อยแล้ว</p>" .
                "<p>ทั้งนี้เจ้าหน้าที่ (กิจติยา แก้วมูล) จะมีการประสานงานติดต่อท่านอีกครั้ง</p>" .
                "<p>ขอแสดงความนับถือ<br>กลุ่มงานพัฒนาธุรกิจ (อบรม) ฝ่ายนโยบายและยุทธศาสตร์ สถาบันมาตรวิทยาแห่งชาติ<br>โทรศัพท์ 02 026 5400 ต่อ 8301-3 หรือ 081 840 2902</p>" .
                "</div>";
            $mail->send();
        } catch (Exception $ignored) {
            // ไม่บล็อกการบันทึก หากส่งอีเมลล้มเหลว
        }
    }

    session_destroy();
    echo "<script>alert('บันทึกข้อมูลเรียบร้อยแล้ว'); window.location.href='success.html';</script>";
    exit();
} catch (PDOException $e) {
    echo "<h3>เกิดข้อผิดพลาดในการบันทึกข้อมูล:</h3>" . htmlspecialchars($e->getMessage());
    echo "<p><strong>วิธีแก:</strong> คุณอาจต้องเพิ่มคอลัมน์ที่ขาดหายไปในฐานข้อมูล โดยรันคำสั่ง SQL นี้ใน phpMyAdmin หรือ pgAdmin:</p>";
    echo "<pre style='background:#eee; padding:10px;'>\nALTER TABLE bookings \nADD COLUMN lab_tool VARCHAR(255);\nALTER TABLE bookings ADD COLUMN request_date DATE;\nALTER TABLE bookings ADD COLUMN reference_no VARCHAR(100);\nALTER TABLE bookings ADD COLUMN fiscal_year VARCHAR(20);\nALTER TABLE bookings ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;\n</pre>";
    $conn = null;
    exit();
}

$conn = null;
?>
