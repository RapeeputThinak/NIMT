<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db_connection.php';

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'invalid id']);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT id, contact_email, email_sent FROM bookings WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        echo json_encode(['success' => true, 'row' => $row]);
    } else {
        echo json_encode(['success' => false, 'error' => 'not found']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'DB query failed']);
}
