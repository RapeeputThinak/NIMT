<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db_connection.php';

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'invalid id']);
    exit;
}

try {
    $stmt = $conn->prepare("UPDATE bookings SET email_sent = 0 WHERE id = :id");
    $stmt->execute([':id' => $id]);
    echo json_encode(['success' => true, 'id' => $id]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'DB query failed']);
}
