<?php
require_once __DIR__ . '/db_connection.php';

try {
    $stmt = $conn->prepare("SELECT id, created_at FROM bookings ORDER BY id DESC LIMIT 5");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($rows)) {
        echo "No rows found in bookings.\n";
    } else {
        foreach ($rows as $r) {
            $ts = $r['created_at'] ?? 'NULL';
            echo "id: {$r['id']}\tcreated_at: {$ts}\n";
        }
    }
} catch (PDOException $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    exit(1);
}

$conn = null;
