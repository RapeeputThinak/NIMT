<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db_connection.php';

try {
    $stmt = $conn->query("SELECT id, contact_email, email_sent FROM bookings LIMIT 20");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'rows' => $rows]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'DB query failed']);
}
