<?php
require_once __DIR__ . '/admin_auth.php';
require_admin();
require_csrf_token();

$configFile = __DIR__ . '/pricing_config.json';
$config = [];
if (file_exists($configFile)) {
    $raw = file_get_contents($configFile);
    $config = json_decode($raw, true) ?? [];
}

$message = '';
$isError = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $posted = $_POST['pricing'] ?? [];
    foreach ($posted as $section => $values) {
        if (!isset($config[$section]) || !is_array($values)) {
            continue;
        }
        foreach ($values as $key => $value) {
            $config[$section][$key] = trim((string)$value);
        }
    }

    $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        $message = 'ไม่สามารถบันทึกค่าได้ โปรดลองใหม่อีกครั้ง';
        $isError = true;
    } else {
        file_put_contents($configFile, $json);
        $message = 'บันทึกค่าราคาสำเร็จแล้ว';
        $isError = false;
    }
}

// กำหนดลำดับตารางที่ต้องแสดง
$displayOrder = [
    'Inhouse_form_TH',
    'Inhouse_form_EN',
    'Inhouse_services_TH',
    'Inhouse_services_EN',
    'Metrology_form_TH',
    'Metrology_form_EN',
    'Metrology_services_TH',
    'Metrology_services_EN',
    'Academic_form_TH',
    'Academic_form_EN',
    'Academic_services_TH',
    'Academic_services_EN',
];

// จัดเรียงตารางตามลำดับที่กำหนด
$orderedConfig = [];
foreach ($displayOrder as $key) {
    if (isset($config[$key])) {
        $orderedConfig[$key] = $config[$key];
    }
}

function humanLabel(string $pageKey): string
{
    return str_replace(['_', '-'], ' ', $pageKey);
}

function getCategoryFromKey(string $pageKey): string
{
    if (strpos($pageKey, 'Inhouse') !== false) {
        return 'Inhouse';
    } elseif (strpos($pageKey, 'Metrology') !== false) {
        return 'Metrology';
    } elseif (strpos($pageKey, 'Academic') !== false) {
        return 'Academic';
    }
    return '';
}

function getFormTypeFromKey(string $pageKey): string
{
    if (strpos($pageKey, 'form') !== false) {
        return 'Form';
    } elseif (strpos($pageKey, 'services') !== false) {
        return 'Services';
    }
    return '';
}

function getLanguageFromKey(string $pageKey): string
{
    if (strpos($pageKey, '_TH') !== false) {
        return 'ไทย (TH)';
    } elseif (strpos($pageKey, '_EN') !== false) {
        return 'English (EN)';
    }
    return '';
}

function humanFieldLabel(string $fieldKey, string $language): string
{
    $labelsTH = [
        'theoretical_up_to_20' => 'ค่าทฤษฎี (ไม่เกิน 20 คน)',
        'additional_per_person' => 'ค่าบุคคลเพิ่มเติม',
        'practical_bundle_price' => 'ราคาชุดปฏิบัติ',
        'practical_1_to_7' => 'ปฏิบัติ 1-7 คน',
        'practical_8_to_15' => 'ปฏิบัติ 8-15 คน',
        'vehicle_rental' => 'ค่าเช่าพาหนะ',
        'fuel_per_km' => 'ค่าน้ำมันต่อกม.',
        'air_travel' => 'ค่าตั๋วเครื่องบิน (ไป-กลับ)',
        'accommodation' => 'ค่าที่พัก',
        'food_per_person' => 'ค่าอาหารต่อคน',
        'room_20' => 'ไม่เกิน 20 คน',
        'room_30' => 'ไม่เกิน 30 คน',
        'room_40' => 'ไม่เกิน 40 คน',
        'room_60' => 'ไม่เกิน 60 คน',
        'up_to_60_people' => 'ไม่เกิน 60 คน',
        'more_than_60_up_to_120' => 'เกิน 60 ถึง 120 คน',
        'consulting_fee' => 'ค่าที่ปรึกษา',
        'additional_person_fee' => 'ค่าบุคคลเพิ่ม',
    ];

    $labelsEN = [
        'theoretical_up_to_20' => 'Theoretical fee (up to 20 people)',
        'additional_per_person' => 'Additional person price',
        'practical_bundle_price' => 'Practical bundle price',
        'practical_1_to_7' => 'Practical 1-7 people',
        'practical_8_to_15' => 'Practical 8-15 people',
        'vehicle_rental' => 'Vehicle rental fee',
        'fuel_per_km' => 'Fuel per km',
        'air_travel' => 'Air travel (round-trip)',
        'accommodation' => 'Accommodation fee',
        'food_per_person' => 'Food per person',
        'room_20' => 'Up to 20 people',
        'room_30' => 'Up to 30 people',
        'room_40' => 'Up to 40 people',
        'room_60' => 'Up to 60 people',
        'up_to_60_people' => 'Up to 60 people',
        'more_than_60_up_to_120' => 'More than 60 up to 120 people',
        'consulting_fee' => 'Consulting fee',
        'additional_person_fee' => 'Additional person fee',
    ];

    $labels = strpos($language, 'ไทย') !== false ? $labelsTH : $labelsEN;
    return $labels[$fieldKey] ?? str_replace(['_', '-'], ' ', $fieldKey);
}

function getPageUrl(string $pageKey): string
{
    $map = [
        'Inhouse_form_TH' => 'Inhouse_from.html',
        'Inhouse_form_EN' => 'Inhouse_from_en.html',
        'Inhouse_services_TH' => 'Inhouse_services.html',
        'Inhouse_services_EN' => 'Inhouse_services_en.html',
        'Metrology_form_TH' => 'metrology_form.html',
        'Metrology_form_EN' => 'metrology_form_en.html',
        'Metrology_services_TH' => 'metrology_services.html',
        'Metrology_services_EN' => 'metrology_services_en.html',
        'Academic_form_TH' => 'academic_form.html',
        'Academic_form_EN' => 'academic_form_en.html',
        'Academic_services_TH' => 'academic_services.html',
        'Academic_services_EN' => 'academic_services_en.html',
    ];

    return $map[$pageKey] ?? '#';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>แก้ไขราคาตาราง - NIMT Admin</title>
    <!-- โหลด Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- โหลดฟอนต์ Sarabun -->
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- โหลด Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Sarabun', sans-serif; background-color: #f8fafc; }
    </style>
</head>
<body class="min-h-screen text-slate-800 pb-16">
    
    <!-- Top Navbar -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div class="max-w-6xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <div class="bg-blue-600 text-white p-2 rounded-lg shadow-sm">
                    <i data-lucide="settings-2" class="w-5 h-5"></i>
                </div>
                <h1 class="text-xl font-bold text-slate-900 leading-none">จัดการราคาตาราง (Pricing Config)</h1>
            </div>
            <div class="flex items-center gap-3">
                <a href="admin_select.php" class="hidden sm:flex items-center space-x-2 text-sm font-semibold text-slate-600 hover:text-blue-600 transition-colors bg-slate-100 hover:bg-blue-50 px-4 py-2 rounded-xl">
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                    <span>กลับหน้าแอดมิน</span>
                </a>
            </div>
        </div>
    </header>

    <div class="max-w-6xl mx-auto py-8 px-4 md:px-8">
        
        <!-- Header Section -->
        <div class="mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
                <h2 class="text-2xl font-bold text-slate-900 mb-2">แก้ไขราคาตาราง</h2>
                <p class="text-slate-500 text-sm">จัดการราคาสำหรับ Inhouse / Metrology / Academic ทั้งภาษาไทยและอังกฤษ</p>
                <p class="text-xs text-slate-400 mt-2">รวม 12 ตารางแบบฟอร์ม (Form) และแบบรายละเอียดบริการ (Services)</p>
            </div>
            <div class="flex gap-3">
            </div>
        </div>

        <!-- Live Price Preview -->
        <div class="mb-8 p-6 rounded-3xl border border-slate-200 bg-slate-50 shadow-sm">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                <div>
                    <p class="text-sm font-semibold text-slate-700">ตัวอย่างการเปลี่ยนแปลงราคา</p>
                    <p class="text-sm text-slate-500">อัปเดตราคาตารางที่แก้ไขแบบเรียลไทม์โดยไม่ต้องบันทึกก่อน</p>
                </div>
                <div class="flex flex-wrap items-center gap-3 text-sm text-slate-600">
                    <div class="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 shadow-sm border border-slate-200">
                        <span class="font-semibold text-slate-900">รายการที่เปลี่ยน</span>
                        <span id="preview-change-count" class="text-blue-600">0</span>
                    </div>
                    <div class="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 shadow-sm border border-slate-200">
                        <span class="font-semibold text-slate-900">ตารางที่เปลี่ยน</span>
                        <span id="preview-section-count" class="text-blue-600">0</span>
                    </div>
                </div>
            </div>
            <div id="price-preview" class="grid gap-4 lg:grid-cols-3"></div>
        </div>

        <!-- Alert Message -->
        <?php if ($message): ?>
            <div class="mb-8 p-4 rounded-xl border <?= $isError ? 'bg-red-50 border-red-200 text-red-800' : 'bg-emerald-50 border-emerald-200 text-emerald-800' ?> flex items-center shadow-sm">
                <i data-lucide="<?= $isError ? 'alert-circle' : 'check-circle-2' ?>" class="w-5 h-5 mr-3 shrink-0 <?= $isError ? 'text-red-500' : 'text-emerald-500' ?>"></i>
                <p class="font-medium text-sm"><?= htmlspecialchars($message, ENT_QUOTES | ENT_SUBSTITUTE) ?></p>
            </div>
        <?php endif; ?>

        <!-- Edit Form -->
        <form action="" method="POST" class="space-y-8">
            <?= csrf_input() ?>
            <?php 
            $categories = ['Inhouse', 'Metrology', 'Academic'];
            foreach ($categories as $category): 
                $categoryItems = array_filter($orderedConfig, function($key) use ($category) {
                    return strpos($key, $category) !== false;
                }, ARRAY_FILTER_USE_KEY);
                
                if (empty($categoryItems)) continue;
            ?>
                <!-- หมวดหมู่หลัก -->
                <div class="mb-8">
                    <div class="flex items-center gap-3 mb-6">
                        <div class="w-1 h-8 bg-gradient-to-b from-blue-600 to-indigo-600 rounded-full"></div>
                        <h2 class="text-2xl font-bold text-slate-900 uppercase tracking-wide"><?= htmlspecialchars($category) ?> Training</h2>
                    </div>

                    <div class="grid gap-6 md:grid-cols-2">
                        <?php foreach ($categoryItems as $pageKey => $fields): 
                            $formType = getFormTypeFromKey($pageKey);
                            $language = getLanguageFromKey($pageKey);
                            $isTH = strpos($pageKey, '_TH') !== false;
                        ?>
                            <!-- Card สำหรับแต่ละตาราง -->
                            <section class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden transition-all hover:shadow-lg hover:border-slate-300">
                                
                                <!-- Header Card -->
                                <div class="<?= $isTH ? 'bg-blue-50 border-b-2 border-blue-200' : 'bg-indigo-50 border-b-2 border-indigo-200' ?> px-6 py-4">
                                    <div class="flex items-center justify-between gap-3">
                                        <div class="flex items-center gap-3">
                                            <div class="<?= $isTH ? 'bg-blue-100 text-blue-600' : 'bg-indigo-100 text-indigo-600' ?> p-2 rounded-lg">
                                                <i data-lucide="<?= $formType === 'Form' ? 'file-text' : 'list' ?>" class="w-5 h-5"></i>
                                            </div>
                                            <div>
                                                <p class="text-sm font-semibold text-slate-600 capitalize"><?= htmlspecialchars($formType) ?></p>
                                                <p class="text-xs text-slate-500 font-mono"><?= htmlspecialchars($pageKey) ?></p>
                                            </div>
                                        </div>
                                        <div class="flex items-center gap-2">
                                            <span class="text-xs font-bold px-2.5 py-1 rounded-full <?= $isTH ? 'bg-blue-200 text-blue-700' : 'bg-indigo-200 text-indigo-700' ?>">
                                                <?= htmlspecialchars($language) ?>
                                            </span>
                                            <a href="<?= htmlspecialchars(getPageUrl($pageKey)) ?>" target="_blank" class="text-xs font-semibold text-slate-600 hover:text-slate-900 underline">
                                                ดูหน้าจริง
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <!-- Fields Grid -->
                                <div class="p-6">
                                    <div class="grid gap-4">
                                        <?php foreach ($fields as $fieldKey => $fieldValue): ?>
                                            <label class="block group">
                                                <span class="block text-sm font-semibold text-slate-700 mb-1.5 capitalize transition-colors group-hover:text-blue-600">
                                                    <?= htmlspecialchars(humanFieldLabel($fieldKey, $language)) ?>
                                                </span>
                                                <div class="relative">
                                                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                                        <i data-lucide="tag" class="w-4 h-4 text-slate-400"></i>
                                                    </div>
                                                    <input type="text"
                                                           name="pricing[<?= htmlspecialchars($pageKey) ?>][<?= htmlspecialchars($fieldKey) ?>]"
                                                           value="<?= htmlspecialchars($fieldValue) ?>"
                                                           data-page="<?= htmlspecialchars($pageKey) ?>"
                                                           data-field="<?= htmlspecialchars($fieldKey) ?>"
                                                           class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm font-medium text-slate-900 pricing-input"
                                                    />
                                                </div>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>

                                    <div class="mt-6 bg-slate-50 rounded-2xl border border-slate-200 p-4">
                                        <p class="text-sm font-semibold text-slate-700 mb-3">ตารางราคาสำหรับหน้านี้</p>
                                        <div class="overflow-x-auto rounded-lg border border-slate-200 bg-white">
                                            <table class="min-w-full text-sm text-left text-slate-700">
                                                <thead class="bg-slate-100 text-slate-600">
                                                    <tr>
                                                        <th class="px-4 py-3 font-semibold">รายการ</th>
                                                        <th class="px-4 py-3 font-semibold">ราคา</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($fields as $fieldKey => $fieldValue): ?>
                                                        <tr class="border-t border-slate-200">
                                                            <td class="px-4 py-3"><?= htmlspecialchars(humanFieldLabel($fieldKey, $language)) ?></td>
                                                            <td class="px-4 py-3 font-semibold text-slate-900"><?= htmlspecialchars($fieldValue) ?></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <!-- Action Area (Sticky) -->
            <div class="mt-12 sticky bottom-0 bg-white p-6 rounded-2xl shadow-lg border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div class="flex items-center text-sm text-slate-500">
                    <i data-lucide="info" class="w-4 h-4 mr-2 text-blue-500"></i>
                    <span>บันทึกข้อมูลลงใน <code class="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded text-xs ml-1">pricing_config.json</code></span>
                </div>
                <button type="submit" class="w-full sm:w-auto inline-flex items-center justify-center space-x-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 px-8 py-3 text-sm font-bold text-white shadow-md hover:from-blue-700 hover:to-indigo-700 transition-all transform hover:-translate-y-0.5 hover:shadow-lg">
                    <i data-lucide="save" class="w-4 h-4"></i>
                    <span>บันทึกการเปลี่ยนแปลง</span>
                </button>
            </div>
            
        </form>
    </div>

    <script>
        // สร้างไอคอนจาก Lucide
        lucide.createIcons();

        const initialPricingState = {};

        function buildPricePreview() {
            const previewContainer = document.getElementById('price-preview');
            const changeCountEl = document.getElementById('preview-change-count');
            const sectionCountEl = document.getElementById('preview-section-count');
            const inputs = document.querySelectorAll('.pricing-input');
            const sections = {};
            let changedFields = 0;

            inputs.forEach(input => {
                const page = input.dataset.page;
                const field = input.dataset.field;
                const currentValue = input.value;
                const originalValue = initialPricingState[page]?.[field] ?? '';
                const changed = currentValue !== originalValue;

                if (!sections[page]) {
                    sections[page] = { page, fields: {}, changedCount: 0 };
                }

                sections[page].fields[field] = {
                    currentValue,
                    originalValue,
                    changed,
                };
                if (changed) {
                    sections[page].changedCount += 1;
                    changedFields += 1;
                }
            });

            const changedSections = Object.values(sections).filter(section => section.changedCount > 0);
            changeCountEl.textContent = changedFields;
            sectionCountEl.textContent = changedSections.length;

            if (changedSections.length === 0) {
                previewContainer.innerHTML = '<div class="col-span-1 rounded-3xl border border-dashed border-slate-300 bg-white/80 p-8 text-center text-slate-500 shadow-sm"><p class="text-lg font-semibold mb-2">ยังไม่มีการเปลี่ยนแปลงราคา</p><p class="text-sm">แก้ไขช่องใดช่องหนึ่งด้านล่างเพื่อดูตัวอย่างการเปลี่ยนแปลงแบบเรียลไทม์</p></div>';
                return;
            }

            const previewHtml = changedSections.map(section => {
                const sectionLabel = section.page.replace(/_/g, ' ');
                const rows = Object.entries(section.fields)
                    .filter(([, data]) => data.changed)
                    .map(([field, data]) => {
                        return `\
                        <li class="grid grid-cols-[1fr_auto] gap-4 items-center py-2 border-b border-slate-100 last:border-b-0">\
                            <div>\
                                <p class="text-sm font-semibold text-slate-800">${field.replace(/[_-]/g, ' ')}</p>\
                                <p class="text-xs text-slate-500">เดิม: <span class="line-through text-slate-400">${data.originalValue || 'ว่าง'}</span></p>\
                            </div>\
                            <div class="text-right">\
                                <p class="text-sm font-bold text-emerald-700">${data.currentValue || '-'}</p>\
                            </div>\
                        </li>`;
                    }).join('');

                return `\
                    <div class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">\
                        <div class="mb-4 flex items-center justify-between gap-2">\
                            <div>\
                                <p class="text-sm font-semibold text-slate-800">${sectionLabel}</p>\
                                <p class="text-xs text-slate-500">มีการเปลี่ยน ${section.changedCount} รายการ</p>\
                            </div>\
                            <span class="inline-flex items-center rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">เปลี่ยน</span>\
                        </div>\
                        <ul class="space-y-2 text-sm text-slate-600">${rows}</ul>\
                    </div>`;
            }).join('');

            previewContainer.innerHTML = previewHtml;
            lucide.createIcons();
        }

        function initializePricingPreview() {
            document.querySelectorAll('.pricing-input').forEach(input => {
                const page = input.dataset.page;
                const field = input.dataset.field;
                if (!initialPricingState[page]) initialPricingState[page] = {};
                initialPricingState[page][field] = input.value;
                input.addEventListener('input', buildPricePreview);
            });
            buildPricePreview();
        }

        initializePricingPreview();
    </script>
</body>
</html>