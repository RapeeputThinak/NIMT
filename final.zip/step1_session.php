<?php
session_start();

function normalizeCategory(string $category): string {
    $category = trim((string)$category);
    if ($category === '') {
        return '';
    }

    $aliasMap = [
        'inhouse-th' => 'Inhouse-TH',
        'inhouse-en' => 'Inhouse-EN',
        'academic-th' => 'Academic-TH',
        'academic-en' => 'Academic-EN',
        'metrology-th' => 'Metrology-TH',
        'metrology-en' => 'Metrology-EN',
    ];

    $key = strtolower(str_replace([' ', '_'], '-', $category));
    return $aliasMap[$key] ?? $category;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = $_POST;
    if (isset($data['category'])) {
        $data['category'] = normalizeCategory($data['category']);
    }
    $_SESSION['data_page1'] = $data;

    $nextPage = $_POST['next_page'] ?? '';
    $allowedPages = [
        'Inhouse_services.html',
        'academic_services.html',
        'metrology_services.html',
        'Inhouse_services_en.html',
        'academic_services_en.html',
        'metrology_services_en.html',
        'index2.html'
    ];

    if (!in_array($nextPage, $allowedPages, true)) {
        $nextPage = 'index2.html';
    }

    // Redirect relative to the current script folder to avoid losing the project path
    $base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '\/');
    if ($base === '') {
        $redirectUrl = '/' . ltrim($nextPage, '/');
    } else {
        $redirectUrl = $base . '/' . ltrim($nextPage, '/');
    }
    header("Location: $redirectUrl");
    exit();
}
?>