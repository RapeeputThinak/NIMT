document.addEventListener('DOMContentLoaded', async () => {
  const rawPageKey = document.body.dataset.pricingPage;
  if (!rawPageKey) {
    return;
  }

  const normalizePageKey = (key) => {
    if (!key) {
      return key;
    }

    const normalized = key
      .trim()
      .replace(/[-\s]+/g, '_')
      .replace(/_+/g, '_')
      .toLowerCase();

    const map = {
      'inhouse_form_th': 'Inhouse_form_TH',
      'inhouse_form_en': 'Inhouse_form_EN',
      'inhouse_services_th': 'Inhouse_services_TH',
      'inhouse_services_en': 'Inhouse_services_EN',
      'academic_form_th': 'Academic_form_TH',
      'academic_form_en': 'Academic_form_EN',
      'academic_services_th': 'Academic_services_TH',
      'academic_services_en': 'Academic_services_EN',
      'metrology_form_th': 'Metrology_form_TH',
      'metrology_form_en': 'Metrology_form_EN',
      'metrology_services_th': 'Metrology_services_TH',
      'metrology_services_en': 'Metrology_services_EN',
    };

    return map[normalized] || key;
  };

  const pageKey = normalizePageKey(rawPageKey);

  try {
    const configUrl = new URL('pricing_config.json', window.location.href).href;
    const response = await fetch(configUrl, { cache: 'no-store' });
    if (!response.ok) {
      console.error('Unable to load pricing configuration:', response.statusText);
      return;
    }

    const config = await response.json();
    let pageConfig = config[pageKey];
    if (!pageConfig && rawPageKey) {
      const fallbackKey = Object.keys(config).find((key) => key.toLowerCase() === rawPageKey.trim().toLowerCase());
      pageConfig = fallbackKey ? config[fallbackKey] : undefined;
    }

    if (!pageConfig) {
      console.warn('No pricing section found for', rawPageKey, pageKey);
      return;
    }

    document.querySelectorAll('[data-price-key]').forEach((element) => {
      const key = element.dataset.priceKey;
      if (!key) {
        return;
      }
      const value = pageConfig[key];
      if (value !== undefined) {
        element.textContent = value;
      }
    });
  } catch (error) {
    console.error('Pricing loader error:', error);
  }
});
